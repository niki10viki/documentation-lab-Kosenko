# Технічна документація API CineBook

## GET /movies
Отримати список фільмів та сеансів

**Приклад запиту**
```http
GET /movies HTTP/1.1
Host: api.cinebook.example.com
